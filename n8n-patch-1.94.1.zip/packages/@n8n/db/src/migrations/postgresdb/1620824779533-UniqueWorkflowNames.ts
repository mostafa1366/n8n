import { UniqueWorkflowNames1620821879465 } from '../common/1620821879465-UniqueWorkflowNames';

export class UniqueWorkflowNames1620824779533 extends UniqueWorkflowNames1620821879465 {
	indexSuffix = 'a252c527c4c89237221fe2c0ab';
}
