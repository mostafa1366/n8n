import { AddJsonKeyPinData1659888469333 } from '../common/1659888469333-AddJsonKeyPinData';

export class AddJsonKeyPinData1659895550980 extends AddJsonKeyPinData1659888469333 {}
