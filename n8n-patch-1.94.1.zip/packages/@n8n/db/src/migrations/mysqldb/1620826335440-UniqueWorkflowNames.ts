import { UniqueWorkflowNames1620821879465 } from '../common/1620821879465-UniqueWorkflowNames';

export class UniqueWorkflowNames1620826335440 extends UniqueWorkflowNames1620821879465 {}
