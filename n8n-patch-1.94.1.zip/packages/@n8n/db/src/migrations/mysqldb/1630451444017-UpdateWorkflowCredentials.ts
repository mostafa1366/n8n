import { UpdateWorkflowCredentials1630330987096 } from '../common/1630330987096-UpdateWorkflowCredentials';

export class UpdateWorkflowCredentials1630451444017 extends UpdateWorkflowCredentials1630330987096 {}
